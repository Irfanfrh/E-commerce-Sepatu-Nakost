<?php

$server = "localhost";
$user = "root";
$password = "";
$db = "db_ecommerce_shoes";

$connect = new mysqli($server,$user,$password,$db);
import 'package:flutter/material.dart';

class Asset {
  static const colorBackground = Color(0XFF575FCC);
  static const colorPrimary = Color(0XFF575FCC);
  static const colorAccent = Color(0XFFC3C7FF);
  static const colorTextTitle = Color(0XFF8890FF);
  static const imageBox = 'assets/images/box.jpg';
}

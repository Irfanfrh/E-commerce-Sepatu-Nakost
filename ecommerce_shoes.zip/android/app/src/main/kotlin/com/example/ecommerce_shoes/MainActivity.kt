package com.example.ecommerce_shoes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
